#include<unistd.h>
#include<fcntl.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
    int lenmax=256;
	char bufer[lenmax];
	int first_file,first_file1;
    ssize_t IN_RETURN, OUT_RETURN;    /* Number of bytes returned by read() and write() */
	first_file=open("input.txt",O_RDONLY);
    
	if(first_file<0)
	{
		perror("failed");
		exit(1);
	}
	
    first_file1=open("output.txt",O_WRONLY|O_CREAT, 0666);
    if(first_file1<0)
	{
		perror("failed");
		exit(1);
	}
  
    /* Copy process */
    while((IN_RETURN = read (first_file, &bufer, lenmax)) > 0)
          {
            OUT_RETURN = write (first_file1, &bufer, (ssize_t) IN_RETURN);
            if(OUT_RETURN != IN_RETURN)
               {
                /* Write error */
                perror("write");
                return 4;
               }
           }
	close(first_file);
    close(first_file1);
	return 0;	//exit(0);
}
