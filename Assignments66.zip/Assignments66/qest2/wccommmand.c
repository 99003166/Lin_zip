#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE * new_file;
    char root[100];
    char char1;
    int num_char, num_word, num_line;
    new_file = fopen("input.txt", "r");
    if (new_file == NULL)
    {
        printf("\nnew_file doesn't exist.\n");
        exit(EXIT_FAILURE);
    }

    num_char = num_word = num_line = 0;
    while ((char1 = fgetc(new_file)) != EOF)
    {
        num_char++;
        if (char1 == '\n' || char1 == '\0') /*Used to find new line*/
            num_line++;

        if (char1 == ' ' || char1 == '\t' || char1 == '\n' || char1 == '\0') /*To count the number of words*/ 
            num_word++;
    }
    if (num_char > 0)
    {
        num_word++;
        num_line++;
    }
    printf("\n");
    printf("Total number of lines      = %d\n", num_line);
    printf("Total number of words      = %d\n", num_word);
    printf("Total number of characters = %d\n", num_char);
   

    fclose(new_file);
    return 0;
}
