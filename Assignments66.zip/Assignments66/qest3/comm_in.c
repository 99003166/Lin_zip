#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>

int main()
{
    pid_t retrn;
    int statu;
    int cmmdexe;
    char command[10];
    printf("Enter your commandand:");
    scanf("%s", command);                  
    retrn=fork();
    
    if(retrn<0)
    {
        perror("fork");
        exit(1);
    }
    if(retrn==0)
    {
        cmmdexe=execlp(command,command);
        if(cmmdexe<0)
        {
            perror("execlp");
            exit(2);
        }
        exit(0);
    }
    else
    {
        waitpid(-1,&statu,0); //wait(&statu);
        printf("Parent and Child exit status=%d\n",
			WEXITSTATUS(statu));
    }
}
