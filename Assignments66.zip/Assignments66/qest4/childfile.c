#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define A 125
#define B 158 
#define C 345
    
int main ()
{   
    int i, j;
    long sum;
    printf ("Hello Child\n");
    for (j = 0; j < 25; j++ ) {
        for (i =0; i < 2534564; i++) {
            sum = A * i + B * i * i + C;
            sum %= 543;
           
        }
    }

    printf ("Word completed:Child\n");
    exit (0);
}
